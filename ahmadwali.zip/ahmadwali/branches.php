<?php include('header.php'); ?>

<div class="jumbotron bg-primary text-white text-center home_title">
    <h1>OUR BRANCHES</h1>
    <p class="lead">something about distributions...</p>
</div>

<div class="container mt-5">
    <div class="row">

        <div class="col-md-6 mb-5">
            <div class="card text-center">
                <div class="card-header bg-primary text-white">
                        <div class="row align-items-center">
                            <div class="col">
                                <i>Kabul</i>
                            </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, aspernatur?</p>

                    </div>

                </div>
                <div class="card-footer">
                    
                    <p>0777888999</p>
                    
                </div>
            </div>
        </div>

        
        <div class="col-md-6 mb-5">
            <div class="card text-center">
                <div class="card-header bg-primary text-white">
                        <div class="row align-items-center">
                            <div class="col">
                                <i>Logar</i>
                            </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, aspernatur?</p>

                    </div>

                </div>
                <div class="card-footer">
                    
                    <p>0777888999</p>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<!------ ending brances ----->
<?php include('footer.php'); ?>