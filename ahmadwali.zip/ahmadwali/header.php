<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="dashboard/bootstrap/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    
    <link rel="stylesheet" href="css/about.css">
    <link rel="stylesheet" href="css/partners.css">
    <link rel="stylesheet" href="css/branches.css">
    <link rel="stylesheet" href="css/home.css">
<link rel="stylesheet" href="css/ourteam.css">
    <!-- Font Awesome CSS Internal Link -->
    <link rel="stylesheet" href="dashboard/fontawesome/all.min.css">
    <link rel="stylesheet" href="dashboard/fontawesome/fontawesome.min.css">
    

    <title>Ajmal Mangal Limited | Medical Services</title>
  </head>
  <body>
    <!-- opening and closing time and social media links div-->
    <div class="container-fluid pt-2 pb-2 header_heading">
        <div class="container text-white">
            <div class="row">
                <div class="col-sm-10 center">
                Opening Hours: 9:00AM to 5:00PM 6 days a week
                </div>
                <div class="col-sm-2 center header_social_media_link">
                    <a href="#">
                        <i class="fab fa-twitter pl-2 pr-2"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-instagram pl-2 pr-2"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-facebook-f pl-2 pr-2"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-linkedin pl-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Company Logo and Contacts Info div-->
    <div class="container-fluid">
        <div class="container">
            <div class="row pt-1 pb-1">
                <div class="col-sm-4 logo_center">
                    <img src="images/logo.png" alt="">
                </div>
                <div class="col-sm-2 text-center mt-3 heading_to_hide">
                    <h6>WHATSAPP</i></h6>
                    <small>+93 777889900</small>
                </div>
                <div class="col-sm-2 text-center mt-3 heading_to_hide">
                    <h6>PHONE</h6>
                    <small>+93 786786786</small>
                </div>
                <div class="col-sm-2 text-center mt-3 heading_to_hide">
                    <h6>CONTACT MAIL</h6>
                    <small>INFO@AJMALMANGALLTD.AF</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Page Menu Bar div-->
    <div class="container-fluid menu_custom_design_div">
        <div class="container text-white">
            <div class="row">
                <div class="col-sm-12">
                    <nav class="navbar navbar-expand-lg navbar-dark menu_custom_design_div">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse menu_custom_design" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                            <li class="nav-item active pt-2 pb-2">
                                <a class="nav-link text-white" href="index.php">HOME <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item pt-2 pb-2">
                                <a class="nav-link text-white" href="about.php">ABOUT US</a>
                            </li>
                           <li class="nav-item pt-2 pb-2">
                                <a class="nav-link text-white" href="branches.php">OUR BRANCHES</a>
                            </li>
                            <li class="nav-item pt-2 pb-2 contact_item">
                                <a class="nav-link text-white" href="contact.php">CONTACT US</a>
                            </li>

                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
