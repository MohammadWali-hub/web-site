<div class="jumbotron bg-primary text-white text-center home_title">
    <h1>WELCOME TO AJMAL MANGAL LTD</h1>
    <p>We have honor to provide Best Services To Afghan Nation in Medical Section</p>
    <a href="contact.php" class="btn btn-outline-light"> Contact Us</a>
</div>

<!----------------------- Starting of QUICK LINKS Div ------------------------------------->
<div class="container text-center">
    <div class="row">
        <div class="col-sm-4 pb-2 pt-2 quick_link">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <img src="images/1.png" style="width:30%; border-radius:50%; padding:3px; background-color: #eee;">
                    <h3>Meet Our Office</h3>
                    <p> Main Office:4th Floor Hayat Market Hotel Parwan Kabul Afghanistan</p>
                    Cell: +93764428284
                    <p>Emaill:ajmalmangal.pvt.ltd@gmail.com</p>
                    <a href="contact.php" class="btn btn-outline-warning"> Read more</a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 pb-2 pt-2">
            <div class="card bg-primary text-white">
                <div class="card-body">
                     <img src="images/111.jpg" style="width:30%; border-radius:50%">
                    <h3>About Us</h3>
                    <p>
                        Ajmal Mangal Medical Trading company is a National Trading Company Specialized and Focused in Importing of High-Quality Medical Equipment and Labs Materials
                    </p>
                    <br>
                    <a href="about.php" class="btn btn-outline-warning">Read more</a>
                </div>
            </div>
        </div>

        <div class="col-sm-4 pb-2 pt-2">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <img src="images/12.jpg" style="width:30%; border-radius:50%">
                    <h3>Our Services</h3>
                    <p>Clinical Chemistry <br>
                    Hematology <br>
                    Serology <br>
                    Controls <br>
                    Calibrators <br>
                    </p>
                    <a href="products.php" class="btn btn-outline-warning">Read more</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!----------------------- Ending of QUICK LINKS Div ------------------------------------->



<!------- Founder message --------->
 <div class="container-fluid bg-dark text-white mt-5 mb-3 pt-3 pb-3">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <img src="images/b2.jpg" alt="" width="100%">
            </div>
            <div class="col-sm-8">
                <h1> Founder Message</h1>
                <p>
                    Muhammad Ajmal Azizi Lecturer and Founder of Ajmal Mangal Medical Trading Company that in 2020 Make a Decision based on Gap That was feeling in Medical Section that was to provide High Quality services To Afghan Nation to overcome this recently select One of The Best and High-Class Medical Company “AGAPEE” from Switzerland and we will continue to make large cover area in different part of medical.
                    Our Mission is to do best, provide best and overcome a part of problem that are feeling in our homeland, we will present best services through our top-level management and me as President will control and lead our team to achieve our long-term goals and the designed. <br> <br>
                    <b>“Muhammad Ajmal Azizi” </b>
                </p>
            </div>
        </div>
    </div>
</div>

 <!-------------------- Ending of Founder Div ----------------------------------------------->

 <!-------------------- Starting of Mission, Vision Div -------------------------------------------------->
<section class="mission_vision" style="background-color:white">
    <div class="left">
        <img src="images/mission.jpg" alt=""><br><br>
        <h3>OUR MISSION</h3>
        <p>Our mission is to create consistent value for our customers and supply chain partners that will maximize shareholder value and long-term.... </p>
        <a href="about.php"> Read more</a>
    </div>
        
    <div class="center" >
        <img src="images/branches.jpg" alt=""> <br><br>
        <h3>BRANCHES</h3>
        <p>Main Branch Kabul <br> Khost, Baghlan, <br>  Ghazni, .....</p>
        <a href="branches.php">Read more</a>
    </div>

    <div class="right">
        <img src="images/vision.png" alt=""><br><br>
        <h3>OUR VISION</h3>
        <p>Our vision to be the leading distributor in Afghanistan market having sophisticated sales reporting system...</p>
        <a href="about.php">Read more</a>
    </div>
</section>    

<!--- mission-vision div ends here-->


    <!-------Ajmal Mangal Ltd is the best services------------------------>

<div class="container-fluid bg-dark mt-3 mb-3 pt-4 pb-4">
    <div class="container pb-3">
        <div class="row pb-4">
            <div class="col-sm-12 text-white text-center">
                <h1>Why Choose Us?</h1>
                <a href="#">READ MORE</a>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Best Quality</h5>
                        <p class="card-text">Ajmal Mangal Works hard to improve all the best quality Products to the country to help the market stand Uniqe Amoung all other markets worldwide</p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Reasonable Prices</h5>
                        <p class="card-text">We always care of our people in every condition, we Improve high Quality products to the country with the most cheap prices then any other companies.</p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                </div>                
            </div>

            <div class="col-sm-4">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">On Time Delivery</h5>
                        <p class="card-text">We always try our best to help our customers Enjoy the Express and safe delivary services from Ajmal Mangal anytime You need.</p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                </div>                
            </div>
        </div>
    </div>
</div>
<!--- Ending of Why choosing Us ----->