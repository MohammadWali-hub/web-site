<?php 
    include('header.php');
?>

<div class="jumbotron bg-primary text-white text-center home_title">
    <h1>ABOUT US</h1>
    <p class="lead">something about company...</p>
</div>
<!---------------about company------------>
<section class="founder">
    <div class="left">
        <img src="images/istockphoto-1159740389-612x612.jpg" alt="">
    </div>
    <div class="right">
        <!-- About Us Contents from Database -->
        <h1>About Us</h1>
        <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quaerat vel maxime suscipit veritatis tempora eum eos neque ullam doloremque consequatur, laudantium obcaecati saepe, facere porro ducimus maiores dolore culpa labore sapiente dignissimos magnam? Quidem pariatur dolorum, rerum cum unde accusantium! Perferendis eum, alias minus sint similique natus magni earum asperiores eligendi suscipit aliquam, eos molestias nisi quo ipsum omnis cupiditate.    
        </p>
        
        <!-- Mission -->
        <h1>Mission</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur provident itaque accusamus cumque porro eligendi aliquid animi voluptatibus odit veritatis similique nisi adipisci cum maiores perferendis, tempore perspiciatis, nesciunt quas.</p>
        
        <!-- Vision -->
        <h1>Vision</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nobis molestiae illo ipsam minus a totam omnis modi nemo cum eveniet at, accusamus sunt. Excepturi, laborum. Corrupti quisquam dolores ipsam nesciunt?</p>
    </div>
</section>
<?php include('footer.php'); ?>