<?php 
    include("database.php");
?>

<div class="container-fluid row text-center">
    <div class="col-sm-4 mt-5">
        <div class="card text-white bg-danger mb-3" style="max-width:18rem;">
            <div class="card-header">Requests Received</div>
            <div class="card-body">
                <h4 class="card-title">
                    2
                </h4>
                <a class="btn text-white" href="#">View</a>
            </div>
        </div>
    </div>

    <div class="col-sm-4 mt-5">
        <div class="card text-white bg-success mb-3" style="max-width:18rem;">
            <div class="card-header">No. of users</div>
            <div class="card-body">
                <h4 class="card-title">
    <!-- Selecting total number of records from database -->
    <?php 
        $result = mysqli_query($connect,"select count(1) FROM users");
        $row = mysqli_fetch_array($result);
        $total = $row[0];
        echo $total;
    ?>
                </h4>
                <a class="btn text-white" href="#">View</a>
            </div>
        </div>
    </div>

    <div class="col-sm-4 mt-5">
        <div class="card text-white bg-info mb-3" style="max-width:18rem;">
            <div class="card-header">No. of announcements</div>
            <div class="card-body">
                <h4 class="card-title">
                5
                </h4>
                <a class="btn text-white" href="#">View</a>
            </div>
        </div>
    </div>
</div>
