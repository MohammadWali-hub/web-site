<?php 
    include("database.php");
    $getId = $_GET['del'];
    $delete ="DELETE FROM contactpage WHERE id='$getId'";
    $run = mysqli_query($connect,$delete);

    if($run) {
        header("location:index.php");
    }
?>