<?php
    //session starts here!
    session_start();
    
   include("database.php");
    
    //checking after login submit button is clicked!
    if(isset($_POST['submit'])) {
        $useremail = $_POST['email'];
        $userpassword = MD5($_POST['password']);
    }

    //selecting data from database
    $sql = "SELECT * FROM users WHERE email = '$useremail' AND password = '$userpassword'";

    //running the SQL query
    $query = mysqli_query($connect, $sql);

    //check if record is present
    if(mysqli_num_rows($query)>0) {

        //fetching the rows from table
        while ($row = mysqli_fetch_array($query)) {
            //$_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            //$_SESSION['email'] = $row['email'];
        }
        //$_SESSION['username'] = $rows['username'];
        $_SESSION['success']= "Login Successful";
        $_SESSION['email']= $useremail;
        header('location:index.php');
    } else {
        $_SESSION['fail']= "Incorrect Username/Password";
        header('location:../login.php'); 
    }
    

?>