<?php 
    include("database.php");
    $getId = $_GET['del'];
    $delete ="DELETE FROM users WHERE id='$getId'";
    $run = mysqli_query($connect,$delete);

    if($run) {
        header("location:index.php");
    }
?>