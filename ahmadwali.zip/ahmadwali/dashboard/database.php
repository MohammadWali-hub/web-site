<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'walidb';

$connect = mysqli_connect($host,$user,$pass);
$database = mysqli_select_db($connect,$dbname);

?>