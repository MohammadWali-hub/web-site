<?php 
    session_start();
    if(!isset($_SESSION['email'])) {
        header('location:../login.php');
    }  
    include('header.php'); 
?>

<nav class="navbar navbar-dark fixed-top bg-info flex-md-nowrap p-0 shadow">
    <span class="navbar-brand px-3">Welcome <b><?php echo $_SESSION['username']; ?></b></span>
    <a href="logout.php" class="navbar-brand text-right text-white px-3"><small>Logout</small></a>
</nav>
<br><br>
<!-- dashboard code starts here.... -->

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3 col-md-2 bg-light">
            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Dashboard</a>
                <a class="nav-link" id="v-pills-query-tab" data-toggle="pill" href="#v-pills-query" role="tab" aria-controls="v-pills-query" aria-selected="true">Requests</a>
                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Add Users</a>
            </div>
        </div>
            <div class="col-sm-9 col-md-10">
                <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab"><?php include("main.php"); ?></div>
                <div class="tab-pane fade" id="v-pills-query" role="tabpanel" aria-labelledby="v-pills-query-tab"><?php include("requests.php"); ?></div>
                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab"><?php include("users.php"); ?></div>
            </div>
        </div>
    </div>
</div>


<br><br>
<nav class="navbar navbar-dark fixed-bottom bg-info flex-md-nowrap p-0 shadow">
    <span class="navbar-brand col-sm-12 col-md-12 text-center">© 2021 Copyright: Ajmal Mangal Ltd</span> 
</nav>
<!-- dashboard code ends here.... -->
<?php include('footer.php'); ?>