<?php 
    include("database.php");
    $sql = "SELECT * FROM users";
    $result = $connect -> query($sql);
    if($result -> num_rows > 0)
?>
<div class="alert alert-primary" role="alert">
    Add a New User to access Admin panel / Dashboard
</div>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-6">
        <h3>Add New User</h3>

        <form action="addusers.php" method="post">
            <div class="form-group">
               <!-- <label for="exampleInputName">Username</label> -->
                <input type="text" name="name" placeholder="Enter full name.." required class="form-control" id="exampleInputName" aria-describedby="emailHelp">
                <!--
                    <small id="nameHelp" class="form-text text-muted">Please enter full name</small>
                -->
                </div>
            <div class="form-group">
                <!-- <label for="exampleInputEmail1">Email address</label> -->
                <input type="email" name="email" placeholder="Enter email address.." required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                 <!--
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                -->
            </div>
            <div class="form-group">
                <!--<label for="exampleInputPassword1">Password</label>-->
                <input type="password" name="password" placeholder="Enter your password..." required class="form-control" id="exampleInputPassword1">
            </div>
            <div class="form-group">
                <!--<label for="exampleInputPassword2">Confirm Password</label>-->
                <input type="password" name="cPassword" placeholder="Confirm your password..." required class="form-control" id="exampleInputPassword2">
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" name="addUser" class="btn btn-success">Save</button>
            </form>
    </div>
    <div class="col-sm-2"></div>
</div>

<div class="row">
    <div class="col-sm-10 mx-5 mt-5 text-center">
        <p class="bg-dark text-white p-2">List of Requesters</p>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Date</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
        <?php 
        {
            while($row = $result -> fetch_assoc()){
        ?>
                <tr>
                    <td scope="row"><?php echo $row["id"]; ?></td>
                    <td><?php echo $row["username"]; ?></td>
                    <td><?php echo $row["email"]; ?></td>
                    <td><?php echo $row["date"]; ?></td>
                    <td><a href="deleteUsers.php?del=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
    <?php
        }
    }
    ?>
            </tbody>
        </table>
    </div>
</div>