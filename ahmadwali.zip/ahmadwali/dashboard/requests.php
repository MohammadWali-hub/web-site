<?php 
    include("database.php");
    $sql = "SELECT * FROM contactpage";
    $result = $connect -> query($sql);
    if($result -> num_rows > 0)
?>

<div class="alert alert-primary" role="alert">
    Messages received from contact Page
</div>
<div class="table-responsive">
    <table class="table table-hover table-light">
        <thead>
            <tr>
                <th scope="col">S.No</th>
                <th scope="col">Username</th>
                <th scope="col">Email address</th>
                <th scope="col">Mobile</th>
                <th scope="col">Message or query Details</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
    <?php 
    {
        while($row = $result -> fetch_assoc()){
    ?>
    
            <tr>
                <th scope="row"><?php echo $row["id"]; ?></th>
                <td><?php echo $row["name"]; ?></td>
                <td><?php echo $row["Email"]; ?></td>
                <td><?php echo $row["Phone"]; ?></td>
                <td class="text-wrap"><?php echo $row["message"]; ?></td>
                <td><a href="deleteRequest.php?del=<?php echo $row["id"]; ?>" 
                      class="btn btn-danger">Delete</a></td>
            </tr>
    <?php
        }
    }
    ?>
        </tbody>
    </table>
</div>