<?php
session_start();
include('database.php');
    if(isset($_POST['addUser'])) {        
        $userName = $_POST['name'];
        $userEmail = $_POST['email'];
        $userPassword = MD5($_POST['password']);
        $confirmPassword = MD5($_POST['cPassword']);
        date_default_timezone_set('Asia/Kabul');
        $date = date("Y-m-d");

        /*echo "Welcome <b>".$userName."</b>. your email address is: <b>".$userEmail."</b>.<br>
        Your password is:<b>".$userPassword."</b> your confirm password is: <b>".$confirmPassword."</b>";
        */
        
        if($userPassword != $confirmPassword) {
            $_SESSION['not_match'] = "<br>password and cPassword not matching...";
        ?>
            <script>alert("password and cPassword not matching...");</script>
        <?php
            header('location:index.php');
        } else {
            $sql = "INSERT INTO users (username, email, password, date) 
            VALUES
            ('$userName','$userEmail','$userPassword','$date')";

            if($connect->query($sql) == TRUE) {
                $_SESSION['success'] = "<br>User added successfully...";
        ?>
                <script>alert("User added successfully...");</script>
        <?php
                header('location:index.php');
            } else {
                echo "Error: " .$sql. "<br>" .$connect -> error;
            }

            $connect -> close();
        }
    }
?>