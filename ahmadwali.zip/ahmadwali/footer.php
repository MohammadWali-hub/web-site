    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="dashboard/bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="dashboard/bootstrap/js/popper.min.js"></script>
    <script src="dashboard/bootstrap/js/bootstrap.min.js"></script>

  <div class="container-fluid footer bg-dark">
    <div class="container-fluid pt-5">
        <div class="row">
            <div class="col-sm-3 mt-1 mb-1">
            <img src="images/logo.png" class="p-2 bg-light mb-2" alt="" width="100%">
            <small>
                <p class="text-justify text-white">
                    Ajmal Mangal Medical Trading company is a National Trading Company Specialized and Focused in Importing of High-Quality Medical Equipment and Labs Materials. And Organized as a Trusted Business unit in Afghanistan that Started its corporate offices in Kabul city in 2020 in order to provide high quality Services for our customers.
                </p>
            </small>
            </div>
            <div class="col-sm-3 mt-1 mb-1">
                <p class="text-white" style="font-size:150%">FOLLOW US</p>
                <div id="fb-root"></div>
                <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v11.0"
                    nonce="rUhMYjyj"></script>

                <div class="fb-page" data-href="https://www.facebook.com/ajmalmangal.pvt.ltd" data-tabs="timeline, events, messages"
                    data-width="" data-height="300px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false"
                    data-show-facepile="true">
                    <blockquote cite="https://www.facebook.com/ajmalmangal.pvt.ltd" class="fb-xfbml-parse-ignore"><a
                            href="https://www.facebook.com/ajmalmangal.pvt.ltd">Ajmal Mangal Medical Trading Company</a></blockquote>
                </div> 
            </div>
            <div class="col-sm-3 mt-1 mb-1 text-left">
                <p class="text-white" style="font-size:150%">GET IN TOUCH</p>
                <small class="text-white">
                    <b>Phone </b> +93764428284, <br> 
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+93764428284
                </small> <br>
                <small class="text-white">
                    <b>Email </b> ajmalmangal.pvt.ltd@gmail.com
                </small><br>
                <small class="text-white">
                    <b>Website </b> www.ajmalmangaltd.com
                </small><br>
                <small class="text-white">
                    <b>Address </b> 4th Floor ,Hayat Market ,Hotel Parwan Kabul Afghanistan
                </small>
            </div>
            <div class="col-sm-3 mt-1 mb-1 text-left">
                <p class="text-white" style="font-size:150%">USEFUL LINKS</p>
                <div class="row">
                
                    <div class="col-sm-6">
                    <small>
                        <b class="text-warning"> > </b> <a href="index.php" class="text-white">Home</a> <br>
                        <b class="text-warning"> > </b> <a href="products.php" class="text-white">Products</a> <br>
                        <b class="text-warning"> > </b> <a href="partners.php" class="text-white">Our Partners</a> <br>
                        <b class="text-warning"> > </b> <a href="gallery.php" class="text-white">Gallery</a> <br>
			<b class="text-warning"> > </b> <a href="feedback.php" class="text-white">Feedback</a> <br>
                        <b class="text-warning"> > </b> <a href="#" class="text-white">cPanel</a> <br>
                    </small>
                    </div>

                    <div class="col-sm-6">
                    <small>
                        <b class="text-warning"> > </b> <a href="about.php" class="text-white">About Us</a> <br>
                        <b class="text-warning"> > </b> <a href="branches.php" class="text-white">Branches</a> <br>
                        <b class="text-warning"> > </b> <a href="team.php" class="text-white">Our team</a> <br>
                        <b class="text-warning"> > </b> <a href="login.php" class="text-white">Employee login</a> <br>
                        <b class="text-warning"> > </b> <a href="contact.php" class="text-white">Contact Us</a> <br>
                    </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12 text-white pt-3 pb-3" style="background:#000">
            © 2022 Copyright: Ajmal Mangal Ltd
        </div>
    </div>
</div>
</body>
</html>