<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <title>Login here!</title>
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
            </div>
            <div class="col-sm-4 border border-primary mt-5 p-3 pt-2">
                <p class="h3 text-primary text-center mb-3">Welcome</p>
                <center>
                    <img src="images/logo-login.png" class=" pt-1 pb-1 pl-1 pr-1 bg-primary rounded-circle" width="30%" alt="...">
                </center>
                <form action="dashboard/logincheck.php" method="post">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" name="email" class="form-control" required id="exampleInputEmail1" aria-describedby="emailHelp">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" name="password" class="form-control" required id="exampleInputPassword1">
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary btn-block">LOGIN</button>
                    </form>
            </div>
            <div class="col-sm-4">
                
            </div>
        </div>
    </div>
  </body>
</html>