<!-- Including header.php file -->
<?php include('header.php'); ?>

<!-- Including home.php file -->
<?php include('home.php'); ?>

<!-- Including footer.php file -->
<?php include('footer.php'); ?>