<?php 
    include('header.php'); 

    //database code....
    include('dashboard/database.php');

    if(isset($_POST['submit'])) {        
        $userName = $_POST['name'];
        $userEmail = $_POST['email'];
        $userPhone = $_POST['phone'];
        $userMessage = $_POST['message'];
        

        $sql = "INSERT INTO contactpage (name, Email, Phone, message) 
        VALUES
        ('$userName','$userEmail','$userPhone','$userMessage')";
        
        if($connect->query($sql) == TRUE) {
           // $success = "Query sent successfully...";
        } else {
            //$fail = "Sorry, message not sent<br>";
        } 
        $connect -> close();
    }
?>
<div class="jumbotron bg-primary text-white text-center home_title">
    <h1>CONTACT US</h1>
    <p class="lead">You can leave message to us using the following form.</p>
</div>

<!----- Starting of Products Div ------->
<div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.3099814020397!2d69.14538161457095!3d34.57102229766148!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38d16f26a9f98657%3A0xb55a9abc0d747dfc!2sAjmal%20Mangal%20Medical%20Trading%20Company!5e0!3m2!1sen!2s!4v1625902420744!5m2!1sen!2s" width="100%" height="400px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

            </div>
        </div>
        <div class="row mt-5 mb-5 pt-2 pb-2">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-info pb-3">GET IN TOUCH</h3><br>
                        
                        <i class="fas fa-home text-warning display-4 pb-2"></i>
                        <h5 class="text-secondary">Main office</h5>
                        <p class="lead">
                            <small>
                                4th Floor ,Hayat Market ,Hotel Parwan Kabul Afghanistan
                            </small>
                        </p>
                        <hr>
                        <i class="fas fa-phone text-warning display-4 pb-2"></i>
                        <h5 class="text-secondary">Cell</h5>
                        <p class="lead">
                            <small>
                                +93(0)764764764 /+93(0)786786786
                            </small>
                        </p>
                        <hr>
                        <i class="far fa-envelope text-warning display-4 pb-2"></i>
                        <h5 class="text-secondary">Email</h5>
                        <p class="lead">
                            <small>
                                ajmalmangal.pvt.ltd@gmail.com
                            </small>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 border pt-3 pb-3 pl-4 pr-4">
                <h3 class="text-info pb-5">SEND US MESSAGE</h3>

                <form action="contact.php" method="post">
                    <div class="form-group">
                        <label for="exampleFormControlName">Full name</label>
                        <input type="text" name="name" required class="form-control" id="exampleFormControlName" placeholder="enter name...">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Email address</label>
                        <input type="email" name="email" required class="form-control" id="exampleFormControlInput1" placeholder="enter email...">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlNumber">Phone number</label>
                        <input type="text" name="phone" required class="form-control" id="exampleFormControlNumber" placeholder="enter mobile number...">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Your message</label>
                        <textarea name="message" required class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <input  type="submit" name="submit" value="SEND" class="form-control btn btn-primary">
                    </div>
                </form>        
            </div>
        </div>
    </div>
</div> 

<!--------------------- Ending of contact us Div --------------------------------->
<?php include('footer.php'); ?>